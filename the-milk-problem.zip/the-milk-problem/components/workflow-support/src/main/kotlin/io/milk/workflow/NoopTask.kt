package io.milk.workflow

data class NoopTask(val name: String, val value: String)