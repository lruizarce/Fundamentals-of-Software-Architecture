package io.milk.products

data class PurchaseInfo(val id: Long, val name: String, val amount: Int)